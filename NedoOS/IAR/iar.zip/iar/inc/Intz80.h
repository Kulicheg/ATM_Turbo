/*                            intz80.h

This file contains constants to control generation of interrupt functions.
Please note that options can be combined. See manual: interrupt functions.

*/

#define	DEFAULT_INTERRUPT	  0x00

#define ALTERNATE_SET		  0x01

#define	NMI_INTERRUPT		  0x02

#define JP_TO_HANDLER		  0x04

#define RETURN_BY_RET_INSTRUCTION 0x08
