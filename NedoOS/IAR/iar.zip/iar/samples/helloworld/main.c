
#include <stdio.h>
#include <string.h>
#include <oscalls.h>
#include <intrz80.h>

no_init unsigned char getsbuf[128];

C_task main (int argc, char *argv[]) 
{
	char i = 0;
	os_initstdio();
	puts("Hello World\r\ncmd paraneters:");
	while(i < argc){
		puts(argv[i]);
		i++;
	}
	printf("Enter you name comandir: ");
	gets(getsbuf);
	printf("Hello %s\r\nPress any key",getsbuf);
	getchar();
	return 0;
}   
