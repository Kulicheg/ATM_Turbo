
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <oscalls.h>
#include <intrz80.h>
#include <terminal.c>



C_task main (int argc, char *argv[]) 
{
	int c1;
	os_initstdio();	

for (c1 = 0; c1 < 1000; c1++)
{
	unsigned char x = (rand() % 80)+1;
	unsigned char y = (rand() % 25)+1;
	unsigned char color = (rand() % 8) + 30;
	AT (x, y);
	ATRIB(color);
	putchar('*');
}

	AT (33, 18);
	ATRIB(31);
	puts(" Press any key ");
	getchar();
	return 0;
}   
